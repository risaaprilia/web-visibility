<?php
    class m_user extends CI_Model{
        function __construct()
        {
            parent::__construct();
        }

        function get_login($username,$password){
            $query=$this->db->query("select DEPARTMENTID from USER WHERE USERID = '$username' && PASSWORD='$password' ");
            return $query;
        }
    function get_id_by_username($username,$password){
        $query=$this->db->query("select DEPARTMENTID from USER WHERE USERID = '$username' && PASSWORD='$password'")->row()->DEPARTMENTID;
        return $query;
    }



    }
?>