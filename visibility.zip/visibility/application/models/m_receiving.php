<?php


class m_receiving extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_all_receivingorder(){
        $query =$this->db->query("select * from RECEIVINGORDER");

        return $query;
    }


    function get_all_receivingorder_detail(){
        $query=$this->db->query("select * from RECEIVINGORDER_DETAIL");
        return $query;
    }



}