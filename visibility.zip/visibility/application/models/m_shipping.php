<?php


class m_shipping extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    function get_all_shippingorder(){
        $query=$this->db->query("select * from SHIPPINGORDER");
        return $query;
    }

    function get_all_shippingorder_detail(){
        $query =$this->db->query("select * from SHIPPINGORDER_DETAIL");
        return $query;
    }

}