<section class="content-header">
    <h1>
        Dashboard
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
                <div class="inner">
                    <?php foreach ($receiving->result() as $row){?>
                    <h3><?php echo $row->QTY;?></h3>
                    <?php }?>
                    <p>Receiving Order</p>
                </div>
                <div class="icon">
                    <i class="ion ion-archive"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <?php foreach ($delivery->result() as $row){?>
                    <h3><?php echo $row->QTY;?></h3>
                    <?php }?>
                    <p>Delivery Order</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-send"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>

    </div>
    <!-- /.row -->

    <!-- Main row -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Opened Receiving Orders</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Receiving Order Number</th>
                                <th>Supplier Name</th>
                                <th>Quantity</th>
                                <th>Actual Quantity</th>
                                <th>Package</th>
                                <th>Create Time</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $no=1;
                            foreach ($receiving_table->result() as $data)
                            {?>
                            <tr>
                                <td><?php  echo $no ?></td>
                                <td><?php echo $data->RECEIVINGORDERNUMBER;?>
                                </td>
                                <td><?php echo $data->SUPPLIERNAME;?></td>
                                <td>nanti</td>
                                <td>where can i get this value from?</td>
                                <td>this value too</td>
                                <td><?php echo $data->CREATETIME;?></td>
                                <td><?php $status=$data->STATUS;
                                    if($status=='1')echo "opened";?></td>
                            </tr>
                            <?php $no++;} ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
<!--table 2-->
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Opened Delivery Orders</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Delivery Order Number</th>
                                <th>Supplier Name</th>
                                <th>Quantity</th>
                                <th>Actual Quantity</th>
                                <th>Package</th>
                                <th>Create Time</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $no=1;
                            foreach ($delivery_table->result() as $data)
                            {?>
                                <tr>
                                    <td><?php  echo $no ?></td>
                                    <td><?php echo $data->SHIPPINGORDERNUMBER;?>
                                    </td>
                                    <td><?php echo $data->CUSTOMERNAME;?></td>
                                    <td>nanti</td>
                                    <td>where can i get this value from?</td>
                                    <td>this value too</td>
                                    <td><?php echo $data->CREATETIME;?></td>
                                    <td><?php $status=$data->STATUS;
                                        if($status=='1')echo "opened";?></td>
                                </tr>
                                <?php $no++;} ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->

        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

</section>
<!-- /.content -->