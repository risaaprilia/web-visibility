<!-- Main content -->
<section class="content">


    <!-- Main row -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Manage Receiving Orders</h3>
                    </div>
                    <div class="col-md-3">
                    <a href="<?php echo site_url('Receiving/receive')?>"><button type="button" class="btn b btn-primary">Receive</button></a>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Receiving Order Number</th>
                                <th>Quantity</th>
                                <th>Actual Quantity</th>
                                <th>Package</th>
                                <th>Status</th>
                                <th>Detail</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $no=1;
                            foreach ($receiving_table->result() as $data)
                            {?>
                                <tr>
                                    <td><?php  echo $no ?></td>
                                    <td><?php echo $data->RECEIVINGORDERNUMBER;?>
                                    </td>
                                    <td>get qty from receivingorder_detail where(...) </td>
                                    <td>get all qty from receivingorder_detail </td>
                                    <td>vial</td>
                                    <td><?php $status=$data->STATUS;
                                        if($status=='1')echo "<i class='fa fa-check'></i>";else echo "<i class='fa fa-close'></i>";?></td>
                                    <td>
                                    <a href="Receiving/" class="btn btn-social-icon btn-default"><i class="fa fa-eye"></i></a>
                                    </td>
                                </tr>
                                <?php $no++;} ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->


        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

</section>
<!-- /.content -->