<!-- Main content -->
<section class="content">


    <!-- Main row -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Receiving - Scan</h3>
                    </div>

                    <div class="box-body">
                        <div class="row">
                              <div class="col-xs-12">
                                  <div class="col-xs-6">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control">
                                        <span class="input-group-btn">
                                        <button type="button" class="btn btn-info btn-flat">Scan</button>
                                        </span>
                                    </div>

                                  </div>
                              </div>
                            <div class="col-xs-12">
                                  <div class="col-xs-4">

                                      <div class="form-group">
                                          <label>Scanned ID:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                      <div class="form-group">
                                          <label>GTIN:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                      <div class="form-group">
                                          <label>Batch No:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                      <div class="form-group">
                                          <label>Status:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                  </div>

                                  <div class="col-xs-4">
                                      <div class="form-group">
                                          <label>Order Number :</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                      <div class="form-group">
                                          <label>Product Code:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                      <div class="form-group">
                                          <label>Product Name:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                      <div class="form-group">
                                          <label>Expiration Date:</label>
                                          <input type="text" class="form-control" placeholder="Example ID" disabled>
                                      </div>
                                  </div>
                            </div>

                            <div class="col-xs-12">
                                <div class="col-xs-8">
                                    <a class="box-footer">
                                        <a href="<?php echo site_url('Receiving/display')?>" <button type="submit" class="btn btn-default">Cancel</button></a>
                                        <button type="submit" class="btn btn-info pull-right">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->


        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

</section>
<!-- /.content -->