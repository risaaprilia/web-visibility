<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('m_user');
        $this->load->model('m_receiving');
        $this->load->model('m_shipping');
        $this->load->library('user_agent');
        $this->load->library('session');

        if($this->session->userdata('masuk') != TRUE){
            $url=base_url();
            redirect($url);
        }
    }

    public function index()
    {
        //logged in as a content succes

        $data['receiving']=$this->m_receiving->get_all_receivingorder_detail();
        $data['delivery']=$this->m_shipping->get_all_shippingorder_detail();
        $data['receiving_table']=$this->m_receiving->get_all_receivingorder();
        $data['delivery_table']=$this->m_shipping->get_all_shippingorder();
        $data['content_view']="content/dashboard";
        $this->load->view('content/main',$data);
    }



}