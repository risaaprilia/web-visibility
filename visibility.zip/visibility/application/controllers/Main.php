<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('m_user');
        $this->load->library('user_agent');
        $this->load->library('session');
    }

    public function index()
    {
    // pertama load masuk ke halaman login (index.php)

        $this->load->view('index');
    }

    public function login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $check = $this->m_user->get_login($username, $password);
        if ($check->num_rows() > 0) {
            $id = $this->m_user->get_id_by_username($username, $password);
            $this->session->set_userdata('masuk', TRUE);

            if ($id === '1') {
                //logged in into content
                $this->session->set_userdata('username', $username);
                redirect('Dashboard/index');
            } elseif ($id === '2') {
                echo "masuk 2";
                //          $this->load->view('kabupaten');
            } elseif ($id === '3') {
                echo "masuk 3";
                //          $this->load->view('puskesmas');
            }
        } else {
            //maaf ini masih manual, hehe
            $this->load->view('index2');
        }
    }

       public function logout(){
            $this->session->sess_destroy();
//            redirect('Main/index');
            $url=base_url();
            redirect($url);
//            echo 'aku keluar';
        }


}
