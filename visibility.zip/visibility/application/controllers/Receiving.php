<?php

class Receiving extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('m_user');
        $this->load->model('m_receiving');
        $this->load->model('m_shipping');
        $this->load->library('user_agent');
        $this->load->library('session');

        if ($this->session->userdata('masuk') != TRUE) {
            $url = base_url();
            redirect($url);
        }
    }

     function display(){
         $data['receiving']=$this->m_receiving->get_all_receivingorder_detail();
         $data['receiving_table']=$this->m_receiving->get_all_receivingorder();
        $data['content_view']="content/transaction/receiving";
        $this->load->view('content/main',$data);
    }

    function receive(){
         $data['content_view']="content/transaction/receive";
         $this->load->view('content/main',$data);
    }
}